"""RegressLens performance investigations."""
