# RegressLens investigation regression

**controlled_fixture · COMPLETED · FAIL**

Controlled synthetic fixture

Alternating paired rounds. Percentile bootstrap of mean per-pair relative degradation. Positive values indicate worse performance. One prespecified gate determines the investigation result. Auxiliary intervals are descriptive.

## Observations

- Reference commit `195fc1c4f9e20f2ca0b60f98f6e728932a87d8e5`
- Candidate commit `72e7cc15230b248a32f217a4683eab1e83c80810`
- Gate workload `long-prompt` and metric `ttft_ms_p95`
- Model `fixture-model` at `fixture-v1`
- Tokenizer `fixture-tokenizer` at `fixture-v1`

| Workload | Metric | Relative degradation | Confidence interval | Pairs | Decision |
|---|---|---:|---|---:|---|
| short-prompt | ttft_ms_p95 | +31.0% | +30.0% to +32.0% | 5 | FAIL |
| short-prompt | tpot_ms_p95 | +0.0% | +0.0% to +0.0% | 5 | PASS |
| short-prompt | output_tokens_per_second | +16.1% | +15.6% to +16.6% | 5 | FAIL |
| long-prompt | ttft_ms_p95 | +31.0% | +30.0% to +32.0% | 5 | FAIL |
| long-prompt | tpot_ms_p95 | +0.0% | +0.0% to +0.0% | 5 | PASS |
| long-prompt | output_tokens_per_second | +16.1% | +15.6% to +16.6% | 5 | FAIL |

## Commit localization

- **status** LOCALIZED
- **last_pass** a2927dd8d227179e49b3f90b1f872abe584c62cf
- **first_fail** 465125feec57029d66e73ae7198f1bc7dee7869e
- **candidates** [&#x27;465125feec57029d66e73ae7198f1bc7dee7869e&#x27;]
- **assumption** One persistent crossing of the configured threshold on the first-parent history
- `195fc1c4f9e2` **PASS** · Reference endpoint in a valid endpoint comparison
- `72e7cc15230b` **FAIL** · +31.0%
- `32343b382e63` **SKIP** · Controlled fixture simulates a failed build
- `6a342239cba5` **PASS** · +0.0%
- `a2927dd8d227` **PASS** · +0.0%
- `465125feec57` **FAIL** · +31.0%

## Hypotheses and counterevidence

### Scheduler · SUPPORTED

Queueing may account for the first-token slowdown.

- **Supporting observation** long-prompt / ttft_ms_p95 · 81.63 → 106.9 · +31.0% · runs commit-465125feec57/baseline/long-prompt/0, commit-465125feec57/baseline/long-prompt/1, commit-465125feec57/baseline/long-prompt/2, commit-465125feec57/baseline/long-prompt/3, commit-465125feec57/baseline/long-prompt/4, commit-465125feec57/candidate/long-prompt/0, commit-465125feec57/candidate/long-prompt/1, commit-465125feec57/candidate/long-prompt/2, commit-465125feec57/candidate/long-prompt/3, commit-465125feec57/candidate/long-prompt/4
- **Supporting observation** long-prompt / queue_ms_mean · 23.89 → 52.02 · +117.7% · runs commit-465125feec57/baseline/long-prompt/0, commit-465125feec57/baseline/long-prompt/1, commit-465125feec57/baseline/long-prompt/2, commit-465125feec57/baseline/long-prompt/3, commit-465125feec57/baseline/long-prompt/4, commit-465125feec57/candidate/long-prompt/0, commit-465125feec57/candidate/long-prompt/1, commit-465125feec57/candidate/long-prompt/2, commit-465125feec57/candidate/long-prompt/3, commit-465125feec57/candidate/long-prompt/4
- **Supporting observation** long-prompt / tpot_ms_p95 · 12.44 → 12.44 · +0.0% · runs commit-465125feec57/baseline/long-prompt/0, commit-465125feec57/baseline/long-prompt/1, commit-465125feec57/baseline/long-prompt/2, commit-465125feec57/baseline/long-prompt/3, commit-465125feec57/baseline/long-prompt/4, commit-465125feec57/candidate/long-prompt/0, commit-465125feec57/candidate/long-prompt/1, commit-465125feec57/candidate/long-prompt/2, commit-465125feec57/candidate/long-prompt/3, commit-465125feec57/candidate/long-prompt/4
- **Related source** scheduler.json
- **Proposed experiment** Restore the scheduler/admission change and repeat the same paired load.

### KV Cache · UNVERIFIED

Cache pressure may be increasing request preemptions.

- **Supporting observation** long-prompt / ttft_ms_p95 · 81.63 → 106.9 · +31.0% · runs commit-465125feec57/baseline/long-prompt/0, commit-465125feec57/baseline/long-prompt/1, commit-465125feec57/baseline/long-prompt/2, commit-465125feec57/baseline/long-prompt/3, commit-465125feec57/baseline/long-prompt/4, commit-465125feec57/candidate/long-prompt/0, commit-465125feec57/candidate/long-prompt/1, commit-465125feec57/candidate/long-prompt/2, commit-465125feec57/candidate/long-prompt/3, commit-465125feec57/candidate/long-prompt/4
- **Counterevidence** long-prompt / preemptions · 0 → 0 · Unavailable · runs commit-465125feec57/baseline/long-prompt/0, commit-465125feec57/baseline/long-prompt/1, commit-465125feec57/baseline/long-prompt/2, commit-465125feec57/baseline/long-prompt/3, commit-465125feec57/baseline/long-prompt/4, commit-465125feec57/candidate/long-prompt/0, commit-465125feec57/candidate/long-prompt/1, commit-465125feec57/candidate/long-prompt/2, commit-465125feec57/candidate/long-prompt/3, commit-465125feec57/candidate/long-prompt/4
- **Counterevidence** long-prompt / kv_cache_usage_snapshot · 0.58 → 0.58 · +0.0% · runs commit-465125feec57/baseline/long-prompt/0, commit-465125feec57/baseline/long-prompt/1, commit-465125feec57/baseline/long-prompt/2, commit-465125feec57/baseline/long-prompt/3, commit-465125feec57/baseline/long-prompt/4, commit-465125feec57/candidate/long-prompt/0, commit-465125feec57/candidate/long-prompt/1, commit-465125feec57/candidate/long-prompt/2, commit-465125feec57/candidate/long-prompt/3, commit-465125feec57/candidate/long-prompt/4
- **Proposed experiment** Hold concurrency fixed, then vary available KV blocks or revert the cache change.

### Prefill · UNVERIFIED

Long-prompt prefill may explain part of the first-token slowdown.

- **Supporting observation** long-prompt / ttft_ms_p95 · 81.63 → 106.9 · +31.0% · runs commit-465125feec57/baseline/long-prompt/0, commit-465125feec57/baseline/long-prompt/1, commit-465125feec57/baseline/long-prompt/2, commit-465125feec57/baseline/long-prompt/3, commit-465125feec57/baseline/long-prompt/4, commit-465125feec57/candidate/long-prompt/0, commit-465125feec57/candidate/long-prompt/1, commit-465125feec57/candidate/long-prompt/2, commit-465125feec57/candidate/long-prompt/3, commit-465125feec57/candidate/long-prompt/4
- **Counterevidence** long-prompt / prefill_ms_mean · 28.87 → 28.87 · +0.0% · runs commit-465125feec57/baseline/long-prompt/0, commit-465125feec57/baseline/long-prompt/1, commit-465125feec57/baseline/long-prompt/2, commit-465125feec57/baseline/long-prompt/3, commit-465125feec57/baseline/long-prompt/4, commit-465125feec57/candidate/long-prompt/0, commit-465125feec57/candidate/long-prompt/1, commit-465125feec57/candidate/long-prompt/2, commit-465125feec57/candidate/long-prompt/3, commit-465125feec57/candidate/long-prompt/4
- **Counterevidence** short-prompt / ttft_ms_p95 · 54.75 → 71.71 · +31.0% · runs commit-465125feec57/baseline/short-prompt/0, commit-465125feec57/baseline/short-prompt/1, commit-465125feec57/baseline/short-prompt/2, commit-465125feec57/baseline/short-prompt/3, commit-465125feec57/baseline/short-prompt/4, commit-465125feec57/candidate/short-prompt/0, commit-465125feec57/candidate/short-prompt/1, commit-465125feec57/candidate/short-prompt/2, commit-465125feec57/candidate/short-prompt/3, commit-465125feec57/candidate/short-prompt/4
- **Proposed experiment** Repeat short and long prompts at matched output length and concurrency.


## Independent verification

- **SUPPORTED** · RCA-001 · 465125feec57029d66e73ae7198f1bc7dee7869e · A separate Bad/revert pair tests improvement and a Good/revert pair checks whether residual regression is below the original threshold.
  - ttft_ms_p95 · +0.0% · CI +0.0% to +0.0% · 5 pairs
  - ttft_ms_p95 · -23.7% · CI -24.2% to -23.1% · 5 pairs

## Independent profiling

- Workload long-prompt
- Good `195fc1c4f9e20f2ca0b60f98f6e728932a87d8e5` · Bad `465125feec57029d66e73ae7198f1bc7dee7869e`
- Provenance synthetic_fixture
- Profiling evidence is separate from regression-gate observations.
- good-trace · `profiles/good-trace-9ab30d2c1f37bdb1b41c22dc1b1083fb33600e8ca2472ed12a86e5b4ed8e447e.json.gz`
- bad-trace · `profiles/bad-trace-651af2b98bdd71337bc5c4710959ae4ad79361b685f7d9675c3bcbe52478b6d1.json.gz`
- good-stacks · `profiles/good-stacks-0ca5e4fafaeb4ef16ea25277aa4d51c8487a94e07a6b2828f1802c357acb2647.json`
- bad-stacks · `profiles/bad-stacks-6c92a8b1ccd2d79fb054040e5a9aa15b7fbf1db5b45c16e85ce32692a02bc947.json`

| Kernel | Good summed ms | Bad summed ms | Delta ms |
|---|---:|---:|---:|
| flash_attn_fwd | 4.800 | 7.200 | +2.400 |
| paged_attention | 12.300 | 12.600 | +0.300 |
| gemm_fp16 | 9.400 | 9.400 | +0.000 |

## Reproduction

```sh
python demo/profiling_fixture.py --out .regresslens/profiling-demo
```

Artifact root `/workspace/scratch/6c6c62541f19/regresslens/.regresslens/with-profiling/store/regression`

### Workload and environment

```json
[
  {
    "id": "short-prompt",
    "prompt_tokens": 128,
    "output_tokens": 32,
    "concurrency": 8,
    "requests": 64
  },
  {
    "id": "long-prompt",
    "prompt_tokens": 1024,
    "output_tokens": 32,
    "concurrency": 8,
    "requests": 64
  }
]
```

```json
{
  "gpu": [],
  "kind": "fixture",
  "runtime": {
    "benchmark": "fixture-v1"
  },
  "model": "fixture-model",
  "model_revision": "fixture-v1",
  "tokenizer": "fixture-tokenizer",
  "tokenizer_revision": "fixture-v1",
  "fingerprint": "db615168a479836fffb9f83115d1726a90c856154dd181f682c3119438f3611f",
  "prelaunch_gpu": [],
  "gpu_before_measurement": [],
  "commit": "195fc1c4f9e20f2ca0b60f98f6e728932a87d8e5",
  "worktree_dirty": false,
  "service": null
}
```

### Raw artifacts

- `endpoints/baseline/short-prompt/0` · runs/endpoints/baseline/short-prompt/pair-00/fixture.json
- `endpoints/candidate/short-prompt/0` · runs/endpoints/candidate/short-prompt/pair-00/fixture.json
- `endpoints/candidate/short-prompt/1` · runs/endpoints/candidate/short-prompt/pair-01/fixture.json
- `endpoints/baseline/short-prompt/1` · runs/endpoints/baseline/short-prompt/pair-01/fixture.json
- `endpoints/baseline/short-prompt/2` · runs/endpoints/baseline/short-prompt/pair-02/fixture.json
- `endpoints/candidate/short-prompt/2` · runs/endpoints/candidate/short-prompt/pair-02/fixture.json
- `endpoints/candidate/short-prompt/3` · runs/endpoints/candidate/short-prompt/pair-03/fixture.json
- `endpoints/baseline/short-prompt/3` · runs/endpoints/baseline/short-prompt/pair-03/fixture.json
- `endpoints/baseline/short-prompt/4` · runs/endpoints/baseline/short-prompt/pair-04/fixture.json
- `endpoints/candidate/short-prompt/4` · runs/endpoints/candidate/short-prompt/pair-04/fixture.json
- `endpoints/baseline/long-prompt/0` · runs/endpoints/baseline/long-prompt/pair-00/fixture.json
- `endpoints/candidate/long-prompt/0` · runs/endpoints/candidate/long-prompt/pair-00/fixture.json
- `endpoints/candidate/long-prompt/1` · runs/endpoints/candidate/long-prompt/pair-01/fixture.json
- `endpoints/baseline/long-prompt/1` · runs/endpoints/baseline/long-prompt/pair-01/fixture.json
- `endpoints/baseline/long-prompt/2` · runs/endpoints/baseline/long-prompt/pair-02/fixture.json
- `endpoints/candidate/long-prompt/2` · runs/endpoints/candidate/long-prompt/pair-02/fixture.json
- `endpoints/candidate/long-prompt/3` · runs/endpoints/candidate/long-prompt/pair-03/fixture.json
- `endpoints/baseline/long-prompt/3` · runs/endpoints/baseline/long-prompt/pair-03/fixture.json
- `endpoints/baseline/long-prompt/4` · runs/endpoints/baseline/long-prompt/pair-04/fixture.json
- `endpoints/candidate/long-prompt/4` · runs/endpoints/candidate/long-prompt/pair-04/fixture.json
- `commit-32343b382e63/baseline/short-prompt/0` · runs/commit-32343b382e63/baseline/short-prompt/pair-00/fixture.json
- `commit-6a342239cba5/baseline/short-prompt/0` · runs/commit-6a342239cba5/baseline/short-prompt/pair-00/fixture.json
- `commit-6a342239cba5/candidate/short-prompt/0` · runs/commit-6a342239cba5/candidate/short-prompt/pair-00/fixture.json
- `commit-6a342239cba5/candidate/short-prompt/1` · runs/commit-6a342239cba5/candidate/short-prompt/pair-01/fixture.json
- `commit-6a342239cba5/baseline/short-prompt/1` · runs/commit-6a342239cba5/baseline/short-prompt/pair-01/fixture.json
- `commit-6a342239cba5/baseline/short-prompt/2` · runs/commit-6a342239cba5/baseline/short-prompt/pair-02/fixture.json
- `commit-6a342239cba5/candidate/short-prompt/2` · runs/commit-6a342239cba5/candidate/short-prompt/pair-02/fixture.json
- `commit-6a342239cba5/candidate/short-prompt/3` · runs/commit-6a342239cba5/candidate/short-prompt/pair-03/fixture.json
- `commit-6a342239cba5/baseline/short-prompt/3` · runs/commit-6a342239cba5/baseline/short-prompt/pair-03/fixture.json
- `commit-6a342239cba5/baseline/short-prompt/4` · runs/commit-6a342239cba5/baseline/short-prompt/pair-04/fixture.json
- `commit-6a342239cba5/candidate/short-prompt/4` · runs/commit-6a342239cba5/candidate/short-prompt/pair-04/fixture.json
- `commit-6a342239cba5/baseline/long-prompt/0` · runs/commit-6a342239cba5/baseline/long-prompt/pair-00/fixture.json
- `commit-6a342239cba5/candidate/long-prompt/0` · runs/commit-6a342239cba5/candidate/long-prompt/pair-00/fixture.json
- `commit-6a342239cba5/candidate/long-prompt/1` · runs/commit-6a342239cba5/candidate/long-prompt/pair-01/fixture.json
- `commit-6a342239cba5/baseline/long-prompt/1` · runs/commit-6a342239cba5/baseline/long-prompt/pair-01/fixture.json
- `commit-6a342239cba5/baseline/long-prompt/2` · runs/commit-6a342239cba5/baseline/long-prompt/pair-02/fixture.json
- `commit-6a342239cba5/candidate/long-prompt/2` · runs/commit-6a342239cba5/candidate/long-prompt/pair-02/fixture.json
- `commit-6a342239cba5/candidate/long-prompt/3` · runs/commit-6a342239cba5/candidate/long-prompt/pair-03/fixture.json
- `commit-6a342239cba5/baseline/long-prompt/3` · runs/commit-6a342239cba5/baseline/long-prompt/pair-03/fixture.json
- `commit-6a342239cba5/baseline/long-prompt/4` · runs/commit-6a342239cba5/baseline/long-prompt/pair-04/fixture.json
- `commit-6a342239cba5/candidate/long-prompt/4` · runs/commit-6a342239cba5/candidate/long-prompt/pair-04/fixture.json
- `commit-a2927dd8d227/baseline/short-prompt/0` · runs/commit-a2927dd8d227/baseline/short-prompt/pair-00/fixture.json
- `commit-a2927dd8d227/candidate/short-prompt/0` · runs/commit-a2927dd8d227/candidate/short-prompt/pair-00/fixture.json
- `commit-a2927dd8d227/candidate/short-prompt/1` · runs/commit-a2927dd8d227/candidate/short-prompt/pair-01/fixture.json
- `commit-a2927dd8d227/baseline/short-prompt/1` · runs/commit-a2927dd8d227/baseline/short-prompt/pair-01/fixture.json
- `commit-a2927dd8d227/baseline/short-prompt/2` · runs/commit-a2927dd8d227/baseline/short-prompt/pair-02/fixture.json
- `commit-a2927dd8d227/candidate/short-prompt/2` · runs/commit-a2927dd8d227/candidate/short-prompt/pair-02/fixture.json
- `commit-a2927dd8d227/candidate/short-prompt/3` · runs/commit-a2927dd8d227/candidate/short-prompt/pair-03/fixture.json
- `commit-a2927dd8d227/baseline/short-prompt/3` · runs/commit-a2927dd8d227/baseline/short-prompt/pair-03/fixture.json
- `commit-a2927dd8d227/baseline/short-prompt/4` · runs/commit-a2927dd8d227/baseline/short-prompt/pair-04/fixture.json
- `commit-a2927dd8d227/candidate/short-prompt/4` · runs/commit-a2927dd8d227/candidate/short-prompt/pair-04/fixture.json
- `commit-a2927dd8d227/baseline/long-prompt/0` · runs/commit-a2927dd8d227/baseline/long-prompt/pair-00/fixture.json
- `commit-a2927dd8d227/candidate/long-prompt/0` · runs/commit-a2927dd8d227/candidate/long-prompt/pair-00/fixture.json
- `commit-a2927dd8d227/candidate/long-prompt/1` · runs/commit-a2927dd8d227/candidate/long-prompt/pair-01/fixture.json
- `commit-a2927dd8d227/baseline/long-prompt/1` · runs/commit-a2927dd8d227/baseline/long-prompt/pair-01/fixture.json
- `commit-a2927dd8d227/baseline/long-prompt/2` · runs/commit-a2927dd8d227/baseline/long-prompt/pair-02/fixture.json
- `commit-a2927dd8d227/candidate/long-prompt/2` · runs/commit-a2927dd8d227/candidate/long-prompt/pair-02/fixture.json
- `commit-a2927dd8d227/candidate/long-prompt/3` · runs/commit-a2927dd8d227/candidate/long-prompt/pair-03/fixture.json
- `commit-a2927dd8d227/baseline/long-prompt/3` · runs/commit-a2927dd8d227/baseline/long-prompt/pair-03/fixture.json
- `commit-a2927dd8d227/baseline/long-prompt/4` · runs/commit-a2927dd8d227/baseline/long-prompt/pair-04/fixture.json
- `commit-a2927dd8d227/candidate/long-prompt/4` · runs/commit-a2927dd8d227/candidate/long-prompt/pair-04/fixture.json
- `commit-465125feec57/baseline/short-prompt/0` · runs/commit-465125feec57/baseline/short-prompt/pair-00/fixture.json
- `commit-465125feec57/candidate/short-prompt/0` · runs/commit-465125feec57/candidate/short-prompt/pair-00/fixture.json
- `commit-465125feec57/candidate/short-prompt/1` · runs/commit-465125feec57/candidate/short-prompt/pair-01/fixture.json
- `commit-465125feec57/baseline/short-prompt/1` · runs/commit-465125feec57/baseline/short-prompt/pair-01/fixture.json
- `commit-465125feec57/baseline/short-prompt/2` · runs/commit-465125feec57/baseline/short-prompt/pair-02/fixture.json
- `commit-465125feec57/candidate/short-prompt/2` · runs/commit-465125feec57/candidate/short-prompt/pair-02/fixture.json
- `commit-465125feec57/candidate/short-prompt/3` · runs/commit-465125feec57/candidate/short-prompt/pair-03/fixture.json
- `commit-465125feec57/baseline/short-prompt/3` · runs/commit-465125feec57/baseline/short-prompt/pair-03/fixture.json
- `commit-465125feec57/baseline/short-prompt/4` · runs/commit-465125feec57/baseline/short-prompt/pair-04/fixture.json
- `commit-465125feec57/candidate/short-prompt/4` · runs/commit-465125feec57/candidate/short-prompt/pair-04/fixture.json
- `commit-465125feec57/baseline/long-prompt/0` · runs/commit-465125feec57/baseline/long-prompt/pair-00/fixture.json
- `commit-465125feec57/candidate/long-prompt/0` · runs/commit-465125feec57/candidate/long-prompt/pair-00/fixture.json
- `commit-465125feec57/candidate/long-prompt/1` · runs/commit-465125feec57/candidate/long-prompt/pair-01/fixture.json
- `commit-465125feec57/baseline/long-prompt/1` · runs/commit-465125feec57/baseline/long-prompt/pair-01/fixture.json
- `commit-465125feec57/baseline/long-prompt/2` · runs/commit-465125feec57/baseline/long-prompt/pair-02/fixture.json
- `commit-465125feec57/candidate/long-prompt/2` · runs/commit-465125feec57/candidate/long-prompt/pair-02/fixture.json
- `commit-465125feec57/candidate/long-prompt/3` · runs/commit-465125feec57/candidate/long-prompt/pair-03/fixture.json
- `commit-465125feec57/baseline/long-prompt/3` · runs/commit-465125feec57/baseline/long-prompt/pair-03/fixture.json
- `commit-465125feec57/baseline/long-prompt/4` · runs/commit-465125feec57/baseline/long-prompt/pair-04/fixture.json
- `commit-465125feec57/candidate/long-prompt/4` · runs/commit-465125feec57/candidate/long-prompt/pair-04/fixture.json
- `restore-465125feec57/baseline/short-prompt/0` · runs/restore-465125feec57/baseline/short-prompt/pair-00/fixture.json
- `restore-465125feec57/candidate/short-prompt/0` · runs/restore-465125feec57/candidate/short-prompt/pair-00/fixture.json
- `restore-465125feec57/candidate/short-prompt/1` · runs/restore-465125feec57/candidate/short-prompt/pair-01/fixture.json
- `restore-465125feec57/baseline/short-prompt/1` · runs/restore-465125feec57/baseline/short-prompt/pair-01/fixture.json
- `restore-465125feec57/baseline/short-prompt/2` · runs/restore-465125feec57/baseline/short-prompt/pair-02/fixture.json
- `restore-465125feec57/candidate/short-prompt/2` · runs/restore-465125feec57/candidate/short-prompt/pair-02/fixture.json
- `restore-465125feec57/candidate/short-prompt/3` · runs/restore-465125feec57/candidate/short-prompt/pair-03/fixture.json
- `restore-465125feec57/baseline/short-prompt/3` · runs/restore-465125feec57/baseline/short-prompt/pair-03/fixture.json
- `restore-465125feec57/baseline/short-prompt/4` · runs/restore-465125feec57/baseline/short-prompt/pair-04/fixture.json
- `restore-465125feec57/candidate/short-prompt/4` · runs/restore-465125feec57/candidate/short-prompt/pair-04/fixture.json
- `restore-465125feec57/baseline/long-prompt/0` · runs/restore-465125feec57/baseline/long-prompt/pair-00/fixture.json
- `restore-465125feec57/candidate/long-prompt/0` · runs/restore-465125feec57/candidate/long-prompt/pair-00/fixture.json
- `restore-465125feec57/candidate/long-prompt/1` · runs/restore-465125feec57/candidate/long-prompt/pair-01/fixture.json
- `restore-465125feec57/baseline/long-prompt/1` · runs/restore-465125feec57/baseline/long-prompt/pair-01/fixture.json
- `restore-465125feec57/baseline/long-prompt/2` · runs/restore-465125feec57/baseline/long-prompt/pair-02/fixture.json
- `restore-465125feec57/candidate/long-prompt/2` · runs/restore-465125feec57/candidate/long-prompt/pair-02/fixture.json
- `restore-465125feec57/candidate/long-prompt/3` · runs/restore-465125feec57/candidate/long-prompt/pair-03/fixture.json
- `restore-465125feec57/baseline/long-prompt/3` · runs/restore-465125feec57/baseline/long-prompt/pair-03/fixture.json
- `restore-465125feec57/baseline/long-prompt/4` · runs/restore-465125feec57/baseline/long-prompt/pair-04/fixture.json
- `restore-465125feec57/candidate/long-prompt/4` · runs/restore-465125feec57/candidate/long-prompt/pair-04/fixture.json
- `recovery-465125feec57/baseline/short-prompt/0` · runs/recovery-465125feec57/baseline/short-prompt/pair-00/fixture.json
- `recovery-465125feec57/candidate/short-prompt/0` · runs/recovery-465125feec57/candidate/short-prompt/pair-00/fixture.json
- `recovery-465125feec57/candidate/short-prompt/1` · runs/recovery-465125feec57/candidate/short-prompt/pair-01/fixture.json
- `recovery-465125feec57/baseline/short-prompt/1` · runs/recovery-465125feec57/baseline/short-prompt/pair-01/fixture.json
- `recovery-465125feec57/baseline/short-prompt/2` · runs/recovery-465125feec57/baseline/short-prompt/pair-02/fixture.json
- `recovery-465125feec57/candidate/short-prompt/2` · runs/recovery-465125feec57/candidate/short-prompt/pair-02/fixture.json
- `recovery-465125feec57/candidate/short-prompt/3` · runs/recovery-465125feec57/candidate/short-prompt/pair-03/fixture.json
- `recovery-465125feec57/baseline/short-prompt/3` · runs/recovery-465125feec57/baseline/short-prompt/pair-03/fixture.json
- `recovery-465125feec57/baseline/short-prompt/4` · runs/recovery-465125feec57/baseline/short-prompt/pair-04/fixture.json
- `recovery-465125feec57/candidate/short-prompt/4` · runs/recovery-465125feec57/candidate/short-prompt/pair-04/fixture.json
- `recovery-465125feec57/baseline/long-prompt/0` · runs/recovery-465125feec57/baseline/long-prompt/pair-00/fixture.json
- `recovery-465125feec57/candidate/long-prompt/0` · runs/recovery-465125feec57/candidate/long-prompt/pair-00/fixture.json
- `recovery-465125feec57/candidate/long-prompt/1` · runs/recovery-465125feec57/candidate/long-prompt/pair-01/fixture.json
- `recovery-465125feec57/baseline/long-prompt/1` · runs/recovery-465125feec57/baseline/long-prompt/pair-01/fixture.json
- `recovery-465125feec57/baseline/long-prompt/2` · runs/recovery-465125feec57/baseline/long-prompt/pair-02/fixture.json
- `recovery-465125feec57/candidate/long-prompt/2` · runs/recovery-465125feec57/candidate/long-prompt/pair-02/fixture.json
- `recovery-465125feec57/candidate/long-prompt/3` · runs/recovery-465125feec57/candidate/long-prompt/pair-03/fixture.json
- `recovery-465125feec57/baseline/long-prompt/3` · runs/recovery-465125feec57/baseline/long-prompt/pair-03/fixture.json
- `recovery-465125feec57/baseline/long-prompt/4` · runs/recovery-465125feec57/baseline/long-prompt/pair-04/fixture.json
- `recovery-465125feec57/candidate/long-prompt/4` · runs/recovery-465125feec57/candidate/long-prompt/pair-04/fixture.json
